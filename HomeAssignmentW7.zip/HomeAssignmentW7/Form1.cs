﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace HomeAssignmentW7
{
    public partial class Form1 : Form
    {

        public int chosenSeats = 0;
        public int[] occupiedSeats = new int[14];
        public int[] bookedSeats = new int[6];

        public Form1()
        {
            InitializeComponent();
            begin();
        }

        public void begin()
        {

        }

        public void clickButton(object sender, EventArgs e)
        {
            var button = sender as Button;
            String text = button.Text;

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < chosenSeats; i++)
            {

                builder.Append(bookedSeats[i]);
                builder.Append(", ");

            }

            label3.Text = builder.ToString();

            if (button.BackColor != Color.IndianRed)
            {
                if (button.BackColor == Color.White)
                {
                    button.BackColor = Color.Lime;

                    bookedSeats[chosenSeats] = int.Parse(button.Text);
                    chosenSeats++;
                }
                else
                {
                    button.BackColor = Color.White;

                    for (int i = 0; i < chosenSeats; i++)
                    {
                        if (bookedSeats[i] == int.Parse(button.Text))
                        {
                            chosenSeats--;
                            for (int j = 0; j < chosenSeats - (i + 1); j++)
                            {
                                bookedSeats[i] = bookedSeats[j];
                            }
                            break;
                        }
                        else
                        {
                            bookedSeats[i] = bookedSeats[i];
                        }
                    }
                }
            }
        }

        public void clickButtonSchedule(object sender, EventArgs e)
        {
            chosenSeats = 0;
            occupiedSeats = new int[14];
            bookedSeats = new int[6];
            var button = sender as Button;

            String text = button.Text;

            no1.BackColor = Color.White;
            no1.Enabled = true;

            no2.BackColor = Color.White;
            no2.Enabled = true;

            no3.BackColor = Color.White;
            no3.Enabled = true;

            no4.BackColor = Color.White;
            no4.Enabled = true;

            no5.BackColor = Color.White;
            no5.Enabled = true;

            no6.BackColor = Color.White;
            no6.Enabled = true;

            no7.BackColor = Color.White;
            no7.Enabled = true;

            no8.BackColor = Color.White;
            no8.Enabled = true;

            no9.BackColor = Color.White;
            no9.Enabled = true;

            no10.BackColor = Color.White;
            no10.Enabled = true;

            no11.BackColor = Color.White;
            no11.Enabled = true;

            no12.BackColor = Color.White;
            no12.Enabled = true;

            no13.BackColor = Color.White;
            no13.Enabled = true;

            no14.BackColor = Color.White;
            no14.Enabled = true;

            no15.BackColor = Color.White;
            no15.Enabled = true;

            no16.BackColor = Color.White;
            no16.Enabled = true;

            no17.BackColor = Color.White;
            no17.Enabled = true;

            no18.BackColor = Color.White;
            no18.Enabled = true;

            no19.BackColor = Color.White;
            no19.Enabled = true;

            no20.BackColor = Color.White;
            no20.Enabled = true;

            Random rand = new Random();
            for (int i = 0; i < 14; i++)
            {
                int randomNumber;

                do
                {

                    randomNumber = rand.Next(1, 20 + 1);

                } while (occupiedSeats.Contains(randomNumber));

                occupiedSeats[i] = randomNumber;
            }

            for (int i = 0; i < 14; i++)
            {
                if (occupiedSeats[i] == int.Parse(no1.Text))
                {
                    no1.BackColor = Color.IndianRed;
                    no1.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no2.Text))
                {
                    no2.BackColor = Color.IndianRed;
                    no2.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no3.Text))
                {
                    no3.BackColor = Color.IndianRed;
                    no3.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no4.Text))
                {
                    no4.BackColor = Color.IndianRed;
                    no4.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no5.Text))
                {
                    no5.BackColor = Color.IndianRed;
                    no5.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no6.Text))
                {
                    no6.BackColor = Color.IndianRed;
                    no6.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no7.Text))
                {
                    no7.BackColor = Color.IndianRed;
                    no7.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no8.Text))
                {
                    no8.BackColor = Color.IndianRed;
                    no8.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no9.Text))
                {
                    no9.BackColor = Color.IndianRed;
                    no9.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no10.Text))
                {
                    no10.BackColor = Color.IndianRed;
                    no10.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no11.Text))
                {
                    no11.BackColor = Color.IndianRed;
                    no11.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no12.Text))
                {
                    no12.BackColor = Color.IndianRed;
                    no12.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no13.Text))
                {
                    no13.BackColor = Color.IndianRed;
                    no13.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no14.Text))
                {
                    no14.BackColor = Color.IndianRed;
                    no14.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no15.Text))
                {
                    no15.BackColor = Color.IndianRed;
                    no15.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no16.Text))
                {
                    no16.BackColor = Color.IndianRed;
                    no16.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no17.Text))
                {
                    no17.BackColor = Color.IndianRed;
                    no17.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no18.Text))
                {
                    no18.BackColor = Color.IndianRed;
                    no18.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no19.Text))
                {
                    no19.BackColor = Color.IndianRed;
                    no19.Enabled = false;
                }
                else if (occupiedSeats[i] == int.Parse(no20.Text))
                {
                    no20.BackColor = Color.IndianRed;
                    no20.Enabled = false;
                }
            }
        }

        private void resetButton_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < chosenSeats; i++)
            {
                if (bookedSeats[i] == int.Parse(no1.Text))
                {
                    no1.BackColor = Color.White;
                    no1.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no2.Text))
                {
                    no2.BackColor = Color.White;
                    no2.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no3.Text))
                {
                    no3.BackColor = Color.White;
                    no3.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no4.Text))
                {
                    no4.BackColor = Color.White;
                    no4.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no5.Text))
                {
                    no5.BackColor = Color.White;
                    no5.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no6.Text))
                {
                    no6.BackColor = Color.White;
                    no6.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no7.Text))
                {
                    no7.BackColor = Color.White;
                    no7.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no8.Text))
                {
                    no8.BackColor = Color.White;
                    no8.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no9.Text))
                {
                    no9.BackColor = Color.White;
                    no9.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no10.Text))
                {
                    no10.BackColor = Color.White;
                    no10.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no11.Text))
                {
                    no11.BackColor = Color.White;
                    no11.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no12.Text))
                {
                    no12.BackColor = Color.White;
                    no12.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no13.Text))
                {
                    no13.BackColor = Color.White;
                    no13.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no14.Text))
                {
                    no14.BackColor = Color.White;
                    no14.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no15.Text))
                {
                    no15.BackColor = Color.White;
                    no15.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no16.Text))
                {
                    no16.BackColor = Color.White;
                    no16.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no17.Text))
                {
                    no17.BackColor = Color.White;
                    no17.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no18.Text))
                {
                    no18.BackColor = Color.White;
                    no18.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no19.Text))
                {
                    no19.BackColor = Color.White;
                    no19.Enabled = true;
                }
                else if (bookedSeats[i] == int.Parse(no20.Text))
                {
                    no20.BackColor = Color.White;
                    no20.Enabled = true;
                }
            }

            bookedSeats = new int[6];

            chosenSeats = 0;

            label3.Text = "";
        }
    }
}

﻿namespace HomeAssignmentW7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.no15 = new System.Windows.Forms.Button();
            this.no20 = new System.Windows.Forms.Button();
            this.no19 = new System.Windows.Forms.Button();
            this.no18 = new System.Windows.Forms.Button();
            this.no17 = new System.Windows.Forms.Button();
            this.no16 = new System.Windows.Forms.Button();
            this.no14 = new System.Windows.Forms.Button();
            this.no7 = new System.Windows.Forms.Button();
            this.no13 = new System.Windows.Forms.Button();
            this.no12 = new System.Windows.Forms.Button();
            this.no11 = new System.Windows.Forms.Button();
            this.no10 = new System.Windows.Forms.Button();
            this.no9 = new System.Windows.Forms.Button();
            this.no8 = new System.Windows.Forms.Button();
            this.no6 = new System.Windows.Forms.Button();
            this.no5 = new System.Windows.Forms.Button();
            this.no4 = new System.Windows.Forms.Button();
            this.no3 = new System.Windows.Forms.Button();
            this.no2 = new System.Windows.Forms.Button();
            this.no1 = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(890, 160);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Movies Schedule";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(413, 102);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 4;
            this.button3.Text = "20.00";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.clickButtonSchedule);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(449, 73);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "16.00";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.clickButtonSchedule);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(368, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "12.00";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.clickButtonSchedule);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Jujutsu Kaisen",
            "Chainsaw Man",
            "Re: Zero ",
            "Sword Art Online",
            "Nisekoi",
            "Kaguya-sama wa Kokurasetai"});
            this.comboBox1.Location = new System.Drawing.Point(187, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(510, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(410, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Movie Tittle";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.no15);
            this.groupBox2.Controls.Add(this.no20);
            this.groupBox2.Controls.Add(this.no19);
            this.groupBox2.Controls.Add(this.no18);
            this.groupBox2.Controls.Add(this.no17);
            this.groupBox2.Controls.Add(this.no16);
            this.groupBox2.Controls.Add(this.no14);
            this.groupBox2.Controls.Add(this.no7);
            this.groupBox2.Controls.Add(this.no13);
            this.groupBox2.Controls.Add(this.no12);
            this.groupBox2.Controls.Add(this.no11);
            this.groupBox2.Controls.Add(this.no10);
            this.groupBox2.Controls.Add(this.no9);
            this.groupBox2.Controls.Add(this.no8);
            this.groupBox2.Controls.Add(this.no6);
            this.groupBox2.Controls.Add(this.no5);
            this.groupBox2.Controls.Add(this.no4);
            this.groupBox2.Controls.Add(this.no3);
            this.groupBox2.Controls.Add(this.no2);
            this.groupBox2.Controls.Add(this.no1);
            this.groupBox2.Location = new System.Drawing.Point(12, 178);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(890, 319);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Seat";
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(169, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(541, 49);
            this.label2.TabIndex = 22;
            this.label2.Text = "Screen";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // no15
            // 
            this.no15.BackColor = System.Drawing.Color.White;
            this.no15.Location = new System.Drawing.Point(359, 198);
            this.no15.Name = "no15";
            this.no15.Size = new System.Drawing.Size(50, 50);
            this.no15.TabIndex = 21;
            this.no15.Text = "15";
            this.no15.UseVisualStyleBackColor = false;
            this.no15.Click += new System.EventHandler(this.clickButton);
            // 
            // no20
            // 
            this.no20.BackColor = System.Drawing.Color.White;
            this.no20.Location = new System.Drawing.Point(532, 269);
            this.no20.Name = "no20";
            this.no20.Size = new System.Drawing.Size(50, 50);
            this.no20.TabIndex = 18;
            this.no20.Text = "20";
            this.no20.UseVisualStyleBackColor = false;
            this.no20.Click += new System.EventHandler(this.clickButton);
            // 
            // no19
            // 
            this.no19.BackColor = System.Drawing.Color.White;
            this.no19.Location = new System.Drawing.Point(588, 198);
            this.no19.Name = "no19";
            this.no19.Size = new System.Drawing.Size(50, 50);
            this.no19.TabIndex = 17;
            this.no19.Text = "19";
            this.no19.UseVisualStyleBackColor = false;
            this.no19.Click += new System.EventHandler(this.clickButton);
            // 
            // no18
            // 
            this.no18.BackColor = System.Drawing.Color.White;
            this.no18.Location = new System.Drawing.Point(532, 198);
            this.no18.Name = "no18";
            this.no18.Size = new System.Drawing.Size(50, 50);
            this.no18.TabIndex = 16;
            this.no18.Text = "18";
            this.no18.UseVisualStyleBackColor = false;
            this.no18.Click += new System.EventHandler(this.clickButton);
            // 
            // no17
            // 
            this.no17.BackColor = System.Drawing.Color.White;
            this.no17.Location = new System.Drawing.Point(476, 198);
            this.no17.Name = "no17";
            this.no17.Size = new System.Drawing.Size(50, 50);
            this.no17.TabIndex = 15;
            this.no17.Text = "17";
            this.no17.UseVisualStyleBackColor = false;
            this.no17.Click += new System.EventHandler(this.clickButton);
            // 
            // no16
            // 
            this.no16.BackColor = System.Drawing.Color.White;
            this.no16.Location = new System.Drawing.Point(303, 259);
            this.no16.Name = "no16";
            this.no16.Size = new System.Drawing.Size(50, 50);
            this.no16.TabIndex = 14;
            this.no16.Text = "16";
            this.no16.UseVisualStyleBackColor = false;
            this.no16.Click += new System.EventHandler(this.clickButton);
            // 
            // no14
            // 
            this.no14.BackColor = System.Drawing.Color.White;
            this.no14.Location = new System.Drawing.Point(303, 198);
            this.no14.Name = "no14";
            this.no14.Size = new System.Drawing.Size(50, 50);
            this.no14.TabIndex = 13;
            this.no14.Text = "14";
            this.no14.UseVisualStyleBackColor = false;
            this.no14.Click += new System.EventHandler(this.clickButton);
            // 
            // no7
            // 
            this.no7.BackColor = System.Drawing.Color.White;
            this.no7.Location = new System.Drawing.Point(247, 142);
            this.no7.Name = "no7";
            this.no7.Size = new System.Drawing.Size(50, 50);
            this.no7.TabIndex = 12;
            this.no7.Text = "7";
            this.no7.UseVisualStyleBackColor = false;
            this.no7.Click += new System.EventHandler(this.clickButton);
            // 
            // no13
            // 
            this.no13.BackColor = System.Drawing.Color.White;
            this.no13.Location = new System.Drawing.Point(247, 198);
            this.no13.Name = "no13";
            this.no13.Size = new System.Drawing.Size(50, 50);
            this.no13.TabIndex = 11;
            this.no13.Text = "13";
            this.no13.UseVisualStyleBackColor = false;
            this.no13.Click += new System.EventHandler(this.clickButton);
            // 
            // no12
            // 
            this.no12.BackColor = System.Drawing.Color.White;
            this.no12.Location = new System.Drawing.Point(588, 142);
            this.no12.Name = "no12";
            this.no12.Size = new System.Drawing.Size(50, 50);
            this.no12.TabIndex = 10;
            this.no12.Text = "12";
            this.no12.UseVisualStyleBackColor = false;
            this.no12.Click += new System.EventHandler(this.clickButton);
            // 
            // no11
            // 
            this.no11.BackColor = System.Drawing.Color.White;
            this.no11.Location = new System.Drawing.Point(532, 142);
            this.no11.Name = "no11";
            this.no11.Size = new System.Drawing.Size(50, 50);
            this.no11.TabIndex = 9;
            this.no11.Text = "11";
            this.no11.UseVisualStyleBackColor = false;
            this.no11.Click += new System.EventHandler(this.clickButton);
            // 
            // no10
            // 
            this.no10.BackColor = System.Drawing.Color.White;
            this.no10.Location = new System.Drawing.Point(476, 142);
            this.no10.Name = "no10";
            this.no10.Size = new System.Drawing.Size(50, 50);
            this.no10.TabIndex = 8;
            this.no10.Text = "10";
            this.no10.UseVisualStyleBackColor = false;
            this.no10.Click += new System.EventHandler(this.clickButton);
            // 
            // no9
            // 
            this.no9.BackColor = System.Drawing.Color.White;
            this.no9.Location = new System.Drawing.Point(359, 142);
            this.no9.Name = "no9";
            this.no9.Size = new System.Drawing.Size(50, 50);
            this.no9.TabIndex = 7;
            this.no9.Text = "9";
            this.no9.UseVisualStyleBackColor = false;
            this.no9.Click += new System.EventHandler(this.clickButton);
            // 
            // no8
            // 
            this.no8.BackColor = System.Drawing.Color.White;
            this.no8.Location = new System.Drawing.Point(303, 142);
            this.no8.Name = "no8";
            this.no8.Size = new System.Drawing.Size(50, 50);
            this.no8.TabIndex = 6;
            this.no8.Text = "8";
            this.no8.UseVisualStyleBackColor = false;
            this.no8.Click += new System.EventHandler(this.clickButton);
            // 
            // no6
            // 
            this.no6.BackColor = System.Drawing.Color.White;
            this.no6.Location = new System.Drawing.Point(588, 86);
            this.no6.Name = "no6";
            this.no6.Size = new System.Drawing.Size(50, 50);
            this.no6.TabIndex = 5;
            this.no6.Text = "6";
            this.no6.UseVisualStyleBackColor = false;
            this.no6.Click += new System.EventHandler(this.clickButton);
            // 
            // no5
            // 
            this.no5.BackColor = System.Drawing.Color.White;
            this.no5.Location = new System.Drawing.Point(532, 86);
            this.no5.Name = "no5";
            this.no5.Size = new System.Drawing.Size(50, 50);
            this.no5.TabIndex = 4;
            this.no5.Text = "5";
            this.no5.UseVisualStyleBackColor = false;
            this.no5.Click += new System.EventHandler(this.clickButton);
            // 
            // no4
            // 
            this.no4.BackColor = System.Drawing.Color.White;
            this.no4.Location = new System.Drawing.Point(476, 86);
            this.no4.Name = "no4";
            this.no4.Size = new System.Drawing.Size(50, 50);
            this.no4.TabIndex = 3;
            this.no4.Text = "4";
            this.no4.UseVisualStyleBackColor = false;
            this.no4.Click += new System.EventHandler(this.clickButton);
            // 
            // no3
            // 
            this.no3.BackColor = System.Drawing.Color.White;
            this.no3.Location = new System.Drawing.Point(359, 86);
            this.no3.Name = "no3";
            this.no3.Size = new System.Drawing.Size(50, 50);
            this.no3.TabIndex = 2;
            this.no3.Text = "3";
            this.no3.UseVisualStyleBackColor = false;
            this.no3.Click += new System.EventHandler(this.clickButton);
            // 
            // no2
            // 
            this.no2.BackColor = System.Drawing.Color.White;
            this.no2.Location = new System.Drawing.Point(303, 86);
            this.no2.Name = "no2";
            this.no2.Size = new System.Drawing.Size(50, 50);
            this.no2.TabIndex = 1;
            this.no2.Text = "2";
            this.no2.UseVisualStyleBackColor = false;
            this.no2.Click += new System.EventHandler(this.clickButton);
            // 
            // no1
            // 
            this.no1.BackColor = System.Drawing.Color.White;
            this.no1.Location = new System.Drawing.Point(247, 86);
            this.no1.Name = "no1";
            this.no1.Size = new System.Drawing.Size(50, 50);
            this.no1.TabIndex = 0;
            this.no1.Text = "1";
            this.no1.UseVisualStyleBackColor = false;
            this.no1.Click += new System.EventHandler(this.clickButton);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(827, 513);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 2;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(12, 451);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(246, 23);
            this.label3.TabIndex = 3;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 548);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "CinemaApp";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button no13;
        private System.Windows.Forms.Button no12;
        private System.Windows.Forms.Button no11;
        private System.Windows.Forms.Button no10;
        private System.Windows.Forms.Button no9;
        private System.Windows.Forms.Button no8;
        private System.Windows.Forms.Button no6;
        private System.Windows.Forms.Button no5;
        private System.Windows.Forms.Button no4;
        private System.Windows.Forms.Button no3;
        private System.Windows.Forms.Button no2;
        private System.Windows.Forms.Button no1;
        private System.Windows.Forms.Button no15;
        private System.Windows.Forms.Button no20;
        private System.Windows.Forms.Button no19;
        private System.Windows.Forms.Button no18;
        private System.Windows.Forms.Button no17;
        private System.Windows.Forms.Button no16;
        private System.Windows.Forms.Button no14;
        private System.Windows.Forms.Button no7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label label3;
    }
}

